const app = require('express').Router()
const axios = require('axios')
const User = require('../../config/models/User')
const CBaudio_db = require('../../config/models/CBaudio_db')
const { v4: uuid4 } = require('uuid')
require('dotenv').config()
const jwt = require('jsonwebtoken')
const { base64encode, base64decode } = require('nodejs-base64');


app.get("/lyrics", (req, res) => {
    var id = req.query.id
    async function cs() {
        const data = await axios({
            method: 'get',
            url: `https://saavn.me/lyrics?id=${id}`
        })
        const json = data.data
        res.send(json.lyrics)
    }
    cs()


});

app.get("/search", (req, res) => {
    var songname = req.query.q
    async function run() {
        try {
            const data = await axios({
                method: 'get',
                url: `https://www.jiosaavn.com/api.php?__call=search.getResults&_format=json&n=100&p=1&_marker=0&ctx=android&q=${songname}`
            })
            const json = data.data.results
            for (k = 0; k < json.length; k++) {
                t = json[k].duration

                const min_time = Math.floor(t / 60)
                const sec_time = (t % 60)
                const song_duration = (min_time + ":" + sec_time)

                res.write(`<div class="audioitem" onclick="avail('${json[k].id}')">
                <div class="audiofile">
                    <div class="audioicon">
                        <img src="${json[k].image}" width="100%" height="100%" alt="">
                        
                        <span class="material-icons material-icons-outlined">
                            play_arrow
                        </span>
                    </div>
                    <div class="audname">
                        ${json[k].song}
                    </div>
                </div>
                <div class="filedate">
                    ${json[k].singers}
                </div>
                <div class="filedate">
                    ${json[k].album} | ${json[k].language}
                </div>
                <div class="audduration">
                    ${song_duration} min
                </div>
            </div>`)
            }
            res.send()
        } catch (err) {
            res.status(500).send()
        }

    }
    run()


});

app.get('/playsong', (req, res) => {
    var songid = req.query.id
    async function ty() {
        try {
            const data = await axios({
                method: 'GET',
                url: `https://saavn.me/song?id=${songid}`
            })
            const json = JSON.stringify(data.data)

            res.send(json)


        } catch (err) {
            res.status(500).send()
        }
    }
    ty()

})

function arrayRemove(arr, value) {

    return arr.filter(function(ele) {
        return ele != value;
    });
}

// adding favsong endpoint..
app.get('/cbaudio/api/fav/:userid/:do_id', (req, res) => {
    const userid = req.params.userid
    const do_id = req.params.do_id
    User.findOne({ _id: userid }, async(err, results) => {
        if (results) {
            if (results.cbaudio) {
                const CB = new CBaudio_db({
                    userid: userid,
                    username: results.username,
                    fullname: results.fullname,
                    uuid: uuid4(),
                    fav_song: do_id

                })
                await CB.save()
                var con = { $set: { cbaudio: false } }
                User.updateOne({ _id: userid }, con, (err, results) => {
                    if (err) {
                        res.send("500 internal server error !")
                    }

                })
            } else {
                CBaudio_db.findOne({ userid: userid }, async(err, listdb) => {

                    const up = listdb.fav_song
                    do_con = false
                    for (i = 0; i < up.length; i++) {
                        if (do_id == up[i]) {
                            do_con = true
                        }

                    }
                    if (do_con) {
                        const newlist = arrayRemove(up, `${do_id}`);
                        const newvalue1 = { $set: { fav_song: newlist } }
                        CBaudio_db.updateOne({ userid: userid }, newvalue1, (err, results) => {
                            if (err) {
                                res.send("500 internal server error !")
                            }

                        })
                        res.status(201).send()
                    } else {
                        up.push(do_id)
                        var newvalue = { $set: { fav_song: up } }
                        CBaudio_db.updateOne({ userid: userid }, newvalue, (err, results) => {
                            if (err) {
                                res.send("500 internal server error !")
                            }

                        })
                        res.status(200).send()
                    }

                })

            }


        }

    })


})

app.get('/token/data/:token', async(req, res) => {
    const token = req.params.token
    const verify = await jwt.verify(token, process.env.privatekey)

    const data = {
        username: verify.username,
        userid: verify.user_id,
    }
    User.findOne({ _id: data.userid }, (err, result) => {
        res.send({ userid: data.userid, cbaudiocon: result.cbaudio })
    })

})

//requesting list fav song
app.get('/cbaudio/api/get_fav_list/:token', async(req, res) => {
    const token = req.params.token
    const verify = await jwt.verify(token, process.env.privatekey)

    const data = {
        username: verify.username,
        userid: verify.user_id,
    }

    CBaudio_db.findOne({ userid: data.userid }, (err, results) => {
        res.send({ favlist: results.fav_song })
    })


})

// cbaudio favourite ,.....

app.get('/:userid/show/favourite', (req, res) => {
    const userid = req.params.userid
    User.findOne({ userid: userid }, (err, results) => {
        if (!results.cbaudio) {
            res.send('nothing to show here')

        } else {
            CBaudio_db.findOne({ userid: userid }, async(err, results) => {
                favdata = results.fav_song
                const y = []
                for (s = favdata.length; s--;) {
                    const data = await axios({
                        method: 'get',
                        url: `https://saavn.me/song?id=${favdata[s]}`
                    })
                    y.push(data.data)
                }
                for (v = 0; v < y.length; v++) {
                    tu = y[v].song_duration

                    const min_time = Math.floor(tu / 60)
                    const sec_time = (tu % 60)
                    const song_duration = (min_time + ":" + sec_time)
                    res.write(`<div class="audioitem" onclick="avail('${y[v].song_id}')">
                    <div class="audiofile">
                        <div class="audioicon">
                            <img src="${y[v].song_image}" width="100%" height="100%" alt="">

                        <span class="material-icons material-icons-outlined">
                            play_arrow
                        </span>
                    </div>
                    <div class="audname">
                        ${y[v].song_name}
                    </div>
                </div>
                <div class="filedate">
                    ${y[v].song_artist}
                </div>
                <div class="filedate">
                    ${y[v].album_name} | ${y[v].song_language}
                </div>
                <div class="audduration">
                    ${song_duration} min
                </div>
            </div>`)
                }
                res.end()

            })

        }
    })
})

app.get('/cbaudio/user/favourite/:userid', (req, res) => {
    const userid = req.params.userid
    CBaudio_db.findOne({ userid: userid }, (err, results) => {
        if (results) {
            const data = {
                userid: userid,
                username: base64encode(results.username),
                en_userid: base64encode(userid),
            }
            res.render('cbaudiofavouritesong.ejs', { data: data })
        }
    })
})

module.exports = app